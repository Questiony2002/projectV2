package com.example.bluecat.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class News {
    private Long id;
    private String title;
    private String url;
    private String publishDate;
    private LocalDateTime createdAt;
} 